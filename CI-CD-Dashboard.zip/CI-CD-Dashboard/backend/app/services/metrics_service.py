from __future__ import annotations

from typing import Sequence

from app.models.build import Build


class MetricsService:
    """Compute dashboard metrics from build records."""

    @staticmethod
    def calculate_success_rate(builds: Sequence[Build]) -> float:
        if not builds:
            return 0.0
        success_count = sum(1 for build in builds if build.status.lower() == "success")
        return round((success_count / len(builds)) * 100, 2)

    @staticmethod
    def calculate_failure_rate(builds: Sequence[Build]) -> float:
        if not builds:
            return 0.0
        failure_count = sum(1 for build in builds if build.status.lower() == "failure")
        return round((failure_count / len(builds)) * 100, 2)

    @staticmethod
    def calculate_average_build_time(builds: Sequence[Build]) -> float:
        if not builds:
            return 0.0
        durations = [build.duration or 0 for build in builds]
        return round(sum(durations) / len(durations), 2)

    @staticmethod
    def calculate_last_build_status(builds: Sequence[Build]) -> str | None:
        if not builds:
            return None
        return builds[0].status

    @staticmethod
    def calculate_total_builds(builds: Sequence[Build]) -> int:
        return len(builds)
