from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from app.models.build import Build
from app.schemas.build import BuildCreate, BuildRead, BuildSummary, RefreshResponse
from app.services.github_service import GitHubService
from app.services.metrics_service import MetricsService


class BuildService:
    """Service for persisting and retrieving build records."""

    def __init__(self, db: Session) -> None:
        self.db = db
        self.github_service = GitHubService()

    def list_builds(self, *, skip: int = 0, limit: int = 20) -> list[BuildRead]:
        builds = self.db.query(Build).order_by(Build.started_at.desc().nullslast(), Build.id.desc()).offset(skip).limit(limit).all()
        return [BuildRead.model_validate(build, from_attributes=True) for build in builds]

    def get_build(self, build_id: int) -> BuildRead | None:
        build = self.db.query(Build).filter(Build.id == build_id).first()
        if build is None:
            return None
        return BuildRead.model_validate(build, from_attributes=True)

    def get_dashboard_summary(self) -> BuildSummary:
        builds = self.db.query(Build).order_by(Build.started_at.desc().nullslast(), Build.id.desc()).all()
        total_builds = MetricsService.calculate_total_builds(builds)
        if total_builds == 0:
            return BuildSummary(
                total_builds=0,
                success_rate=0.0,
                failure_rate=0.0,
                average_build_time=0.0,
                last_build_status=None,
                recent_builds=[],
            )

        recent_builds = [BuildRead.model_validate(build, from_attributes=True) for build in builds[:5]]

        return BuildSummary(
            total_builds=total_builds,
            success_rate=MetricsService.calculate_success_rate(builds),
            failure_rate=MetricsService.calculate_failure_rate(builds),
            average_build_time=MetricsService.calculate_average_build_time(builds),
            last_build_status=MetricsService.calculate_last_build_status(builds),
            recent_builds=recent_builds,
        )

    def refresh_builds(self) -> RefreshResponse:
        try:
            runs = self.github_service.list_workflow_runs(owner="octocat", repo="Hello-World", per_page=5)
        except Exception as exc:
            return RefreshResponse(message=f"Refresh failed: {exc}", refreshed=0)

        for run in runs:
            parsed = self.github_service.parse_run(run)
            existing = self.db.query(Build).filter(Build.build_number == parsed["build_number"]).first()
            if existing is None:
                build = Build(
                    pipeline_name=parsed["pipeline_name"],
                    build_number=parsed["build_number"],
                    workflow_name=parsed["workflow_name"],
                    status=parsed["status"],
                    duration=parsed["duration"],
                    branch=parsed["branch"],
                    commit_id=parsed["commit_id"],
                    commit_message=parsed["commit_message"],
                    author=parsed["author"],
                    started_at=None,
                    completed_at=None,
                    logs=parsed.get("logs_url"),
                )
                self.db.add(build)

        self.db.commit()
        return RefreshResponse(message="Builds refreshed successfully", refreshed=len(runs))
