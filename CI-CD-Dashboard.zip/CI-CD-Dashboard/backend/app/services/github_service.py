from __future__ import annotations

import time
from typing import Any

import requests
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.logging_config import get_logger
from app.models.build import Build

logger = get_logger(__name__)
settings = get_settings()


class GitHubService:
    """Service for fetching workflow run data from the GitHub REST API."""

    def __init__(self) -> None:
        self.base_url = "https://api.github.com"
        self.token = settings.github_token or ""
        self.owner = settings.github_owner or ""
        self.repo = settings.github_repo or ""
        self.headers = {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {self.token}",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _build_headers(self) -> dict[str, str]:
        return {
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {self.token}",
            "X-GitHub-Api-Version": "2022-11-28",
        }

    def _request(self, url: str, *, params: dict[str, Any] | None = None, retries: int = 3) -> dict[str, Any]:
        if not self.token:
            logger.error("GitHub token is missing")
            raise ValueError("GitHub token is not configured")

        last_error: Exception | None = None
        for attempt in range(retries):
            try:
                response = requests.get(url, headers=self._build_headers(), params=params, timeout=15)
                if response.status_code == 401:
                    logger.error("GitHub authentication failed", extra={"status_code": response.status_code})
                    raise PermissionError("GitHub authentication failed")
                if response.status_code == 403:
                    if response.headers.get("X-RateLimit-Remaining") == "0":
                        logger.warning(
                            "GitHub rate limit reached",
                            extra={"reset_time": response.headers.get("X-RateLimit-Reset")},
                        )
                        raise TimeoutError("GitHub rate limit exceeded")
                    logger.warning("GitHub access forbidden", extra={"status_code": response.status_code})
                    raise PermissionError("GitHub access forbidden")
                if response.status_code >= 400:
                    logger.warning(
                        "GitHub API request failed",
                        extra={"status_code": response.status_code, "body": response.text[:500]},
                    )
                    raise RuntimeError(f"GitHub API request failed with status {response.status_code}")

                return response.json()
            except requests.Timeout as exc:
                last_error = exc
                logger.warning("GitHub request timed out, retrying", extra={"attempt": attempt + 1})
                if attempt < retries - 1:
                    time.sleep(2 ** attempt)
            except (PermissionError, TimeoutError, RuntimeError) as exc:
                last_error = exc
                if attempt < retries - 1:
                    time.sleep(2 ** attempt)
                else:
                    raise

        if last_error is not None:
            raise last_error
        raise RuntimeError("GitHub request failed")

    def list_workflow_runs(self, owner: str, repo: str, *, per_page: int = 10, max_pages: int = 1) -> list[dict[str, Any]]:
        all_runs: list[dict[str, Any]] = []
        page = 1
        while page <= max_pages:
            url = f"{self.base_url}/repos/{owner}/{repo}/actions/runs"
            params = {"per_page": per_page, "page": page}
            payload = self._request(url, params=params)
            runs = payload.get("workflow_runs", [])
            if not runs:
                break
            all_runs.extend(runs)
            page += 1

        logger.info(
            "Fetched workflow runs",
            extra={"owner": owner, "repo": repo, "count": len(all_runs)},
        )
        return all_runs

    def parse_run(self, run: dict[str, Any]) -> dict[str, Any]:
        started_at = run.get("run_started_at")
        completed_at = run.get("updated_at")

        head_commit = run.get("head_commit") if isinstance(run.get("head_commit"), dict) else {}
        author_name = None
        if isinstance(head_commit.get("author"), dict):
            author_name = head_commit["author"].get("name")

        return {
            "pipeline_name": run.get("name") or run.get("head_branch") or "unknown",
            "build_number": run.get("run_number"),
            "workflow_name": run.get("name"),
            "status": (run.get("conclusion") or run.get("status") or "unknown").lower(),
            "duration": None,
            "branch": run.get("head_branch"),
            "commit_id": run.get("head_sha"),
            "commit_message": head_commit.get("message"),
            "author": author_name,
            "started_at": started_at,
            "completed_at": completed_at,
            "logs_url": run.get("logs_url"),
        }

    def sync_workflow_runs_to_db(self, db: Session, *, owner: str | None = None, repo: str | None = None, per_page: int = 10, max_pages: int = 1) -> int:
        owner = owner or self.owner
        repo = repo or self.repo
        if not owner or not repo:
            logger.error("GitHub owner or repository is not configured")
            raise ValueError("GitHub owner and repository must be configured")

        runs = self.list_workflow_runs(owner, repo, per_page=per_page, max_pages=max_pages)
        stored_count = 0
        for run in runs:
            parsed = self.parse_run(run)
            existing = db.query(Build).filter(Build.build_number == parsed["build_number"]).first()
            if existing is not None:
                continue

            build = Build(
                pipeline_name=parsed["pipeline_name"],
                build_number=parsed["build_number"],
                workflow_name=parsed["workflow_name"],
                status=parsed["status"],
                duration=parsed["duration"],
                branch=parsed["branch"],
                commit_id=parsed["commit_id"],
                commit_message=parsed["commit_message"],
                author=parsed["author"],
                started_at=parsed["started_at"],
                completed_at=parsed["completed_at"],
                logs=parsed.get("logs_url"),
            )
            db.add(build)
            stored_count += 1

        db.commit()
        logger.info("Synced workflow runs to database", extra={"stored_count": stored_count})
        return stored_count
