// Frontend app entry placeholder.
