// Frontend main entry placeholder.
